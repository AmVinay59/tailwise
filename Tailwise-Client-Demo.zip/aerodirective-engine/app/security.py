import hmac
import os
from typing import Optional

from fastapi import Header, HTTPException


def require_api_key(authorization: Optional[str] = Header(default=None)) -> None:
    expected = os.getenv("AERODIRECTIVE_API_KEY", "")
    if len(expected) < 32:
        raise HTTPException(status_code=503, detail="API authentication is not configured")
    supplied = authorization.removeprefix("Bearer ") if authorization else ""
    if not hmac.compare_digest(supplied, expected):
        raise HTTPException(status_code=401, detail="Unauthorized")


def require_webhook_secret(x_webhook_secret: Optional[str] = Header(default=None)) -> None:
    expected = os.getenv("AERODIRECTIVE_WEBHOOK_SECRET", "")
    if len(expected) < 32:
        raise HTTPException(status_code=503, detail="Webhook authentication is not configured")
    if not x_webhook_secret or not hmac.compare_digest(x_webhook_secret, expected):
        raise HTTPException(status_code=401, detail="Unauthorized webhook")
