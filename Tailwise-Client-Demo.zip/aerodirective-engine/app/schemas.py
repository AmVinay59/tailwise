from datetime import date
from enum import Enum
from typing import Literal, Optional

from pydantic import BaseModel, ConfigDict, Field, HttpUrl, field_validator


class DocumentKind(str, Enum):
    AD = "AD"
    EAD = "EAD"
    PAD = "PAD"
    SIB = "SIB"
    SD = "SD"
    SB = "SB"
    SL = "SL"
    OTHER = "OTHER"


class ProductType(str, Enum):
    AIRCRAFT = "AIRCRAFT"
    ENGINE = "ENGINE"
    PROPELLER = "PROPELLER"
    APPLIANCE = "APPLIANCE"
    PART = "PART"
    UNKNOWN = "UNKNOWN"


class PublicationIn(BaseModel):
    model_config = ConfigDict(extra="forbid")

    source_channel: str = Field(min_length=2, max_length=80)
    source_message_id: Optional[str] = Field(default=None, max_length=200)
    publication_id: str = Field(min_length=1, max_length=120)
    document_kind: DocumentKind
    issuing_authority: str = Field(min_length=2, max_length=120)
    issuer: Optional[str] = Field(default=None, max_length=200)
    revision: str = Field(default="Original", max_length=80)
    publication_date: Optional[date] = None
    effective_date: Optional[date] = None
    source_url: HttpUrl
    product_type: ProductType = ProductType.UNKNOWN
    manufacturer: Optional[str] = Field(default=None, max_length=160)
    models: list[str] = Field(default_factory=list, max_length=100)
    serials: list[str] = Field(default_factory=list, max_length=500)
    part_numbers: list[str] = Field(default_factory=list, max_length=500)
    subject: str = Field(min_length=1, max_length=500)
    compliance_time: Optional[str] = Field(default=None, max_length=1000)
    source_clause: Optional[str] = Field(default=None, max_length=200)
    source_text: Optional[str] = Field(default=None, max_length=20000)

    @field_validator("models", "serials", "part_numbers")
    @classmethod
    def trim_values(cls, values: list[str]) -> list[str]:
        return [v.strip()[:160] for v in values if v.strip()]


class AssetIn(BaseModel):
    asset_id: str = Field(min_length=1, max_length=100)
    product_type: ProductType
    manufacturer: Optional[str] = Field(default=None, max_length=160)
    model: str = Field(min_length=1, max_length=160)
    serial_number: Optional[str] = Field(default=None, max_length=120)
    part_numbers: list[str] = Field(default_factory=list, max_length=500)


class FleetIn(BaseModel):
    assets: list[AssetIn] = Field(min_length=1, max_length=10000)


class IntakeResult(BaseModel):
    publication_id: str
    revision: str
    duplicate: bool
    candidates_created: int
    cases: list[dict]
    notice: str = "Candidate flags are advisory. Authorized human review is required."


class AIExtractRequest(BaseModel):
    source_text: str = Field(min_length=20, max_length=15000)


class WebhookSourceIn(BaseModel):
    model_config = ConfigDict(extra="forbid")
    source_channel: str = Field(min_length=2, max_length=80)
    source_message_id: Optional[str] = Field(default=None, max_length=200)
    source_url: HttpUrl
    source_text: str = Field(min_length=20, max_length=15000)


class DemoAIIntakeIn(BaseModel):
    model_config = ConfigDict(extra="forbid")
    source_channel: str = Field(min_length=2, max_length=80)
    source_message_id: Optional[str] = Field(default=None, max_length=200)
    source_url: HttpUrl
    source_text: str = Field(min_length=20, max_length=15000)
    authorized_for_ai_processing: bool = False


class DemoDocSearchIn(BaseModel):
    model_config = ConfigDict(extra="forbid")
    query: str = Field(min_length=3, max_length=1000)
    authorized_for_ai_processing: bool = False


class AIExtractResponse(BaseModel):
    extracted_fields: dict
    ai_notice: str = "AI extraction is unverified. Compare every field with the official source."
    applicability_determined: Literal[False] = False


class DemoReviewIn(BaseModel):
    model_config = ConfigDict(extra="forbid")
    decision: Literal["REVIEWED_POTENTIAL_MATCH", "REVIEWED_NO_MATCH", "NEEDS_MORE_INFORMATION"]
    reviewer: str = Field(min_length=2, max_length=120)
    notes: str = Field(min_length=3, max_length=2000)
