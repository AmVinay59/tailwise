import hashlib
import re
from typing import Any, Optional


def norm(value: Optional[str]) -> str:
    return re.sub(r"[^A-Z0-9]", "", (value or "").upper())


def match_publication_to_assets(publication: dict[str, Any], assets: list[dict[str, Any]]) -> list[dict[str, Any]]:
    publication_models = {norm(v) for v in publication.get("models", []) if norm(v)}
    publication_serials = {norm(v) for v in publication.get("serials", []) if norm(v)}
    publication_parts = {norm(v) for v in publication.get("part_numbers", []) if norm(v)}
    product_type = publication.get("product_type", "UNKNOWN")
    manufacturer = norm(publication.get("manufacturer"))
    results = []

    for asset in assets:
        reasons: list[str] = []
        type_match = product_type in ("UNKNOWN", asset.get("product_type"))
        if type_match and product_type != "UNKNOWN":
            reasons.append("PRODUCT_TYPE_MATCH")

        model = norm(asset.get("model"))
        model_match = bool(publication_models and model in publication_models)
        if model_match:
            reasons.append("MODEL_EXACT_MATCH")
        elif not publication_models:
            reasons.append("SOURCE_MODEL_MISSING_REVIEW_SCOPE")

        serial = norm(asset.get("serial_number"))
        serial_match = bool(publication_serials and serial and serial in publication_serials)
        if serial_match:
            reasons.append("SERIAL_EXACT_MATCH")

        installed_parts = {norm(v) for v in asset.get("part_numbers", []) if norm(v)}
        part_match = bool(publication_parts & installed_parts)
        if part_match:
            reasons.append("PART_NUMBER_MATCH")

        asset_manufacturer = norm(asset.get("manufacturer"))
        manufacturer_match = not manufacturer or not asset_manufacturer or manufacturer == asset_manufacturer
        strong_match = type_match and manufacturer_match and (model_match or serial_match or part_match)
        candidate_status = "POTENTIAL_MATCH_REQUIRES_HUMAN_REVIEW" if strong_match else "REVIEW_SCOPE_UNCLEAR"
        key = f"{publication['publication_id']}::{publication['revision']}::{asset['asset_id']}"
        case_id = hashlib.sha256(key.encode()).hexdigest()[:24]
        results.append({
            "case_id": case_id,
            "asset_id": asset["asset_id"],
            "candidate_status": candidate_status,
            "match_reasons": reasons or ["NO_EXACT_SCOPE_MATCH_REVIEW_SOURCE"],
            "applicability_status": "UNASSESSED",
            "compliance_status": "OPEN",
            "human_review_required": True,
        })
    return results
