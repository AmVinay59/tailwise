import json
import os
import sqlite3
from pathlib import Path
from typing import Any


DB_PATH = Path(os.getenv("DATABASE_PATH", "./data/aerodirective.sqlite3"))


def connect() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(DB_PATH, timeout=15)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA foreign_keys = ON")
    db.execute("PRAGMA journal_mode = WAL")
    return db


def initialize() -> None:
    with connect() as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS publications (
            tenant_id TEXT NOT NULL,
            publication_id TEXT NOT NULL,
            revision TEXT NOT NULL,
            source_channel TEXT NOT NULL,
            issuing_authority TEXT NOT NULL,
            document_kind TEXT NOT NULL,
            source_url TEXT NOT NULL,
            subject TEXT NOT NULL,
            payload_json TEXT NOT NULL,
            received_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
            PRIMARY KEY (tenant_id, publication_id, revision)
        );
        CREATE TABLE IF NOT EXISTS assets (
            tenant_id TEXT NOT NULL,
            asset_id TEXT NOT NULL,
            payload_json TEXT NOT NULL,
            PRIMARY KEY (tenant_id, asset_id)
        );
        CREATE TABLE IF NOT EXISTS review_cases (
            tenant_id TEXT NOT NULL,
            case_id TEXT NOT NULL,
            publication_id TEXT NOT NULL,
            revision TEXT NOT NULL,
            asset_id TEXT NOT NULL,
            candidate_status TEXT NOT NULL,
            match_reasons_json TEXT NOT NULL,
            applicability_status TEXT NOT NULL DEFAULT 'UNASSESSED',
            compliance_status TEXT NOT NULL DEFAULT 'OPEN',
            human_review_required INTEGER NOT NULL DEFAULT 1,
            created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
            PRIMARY KEY (tenant_id, case_id),
            FOREIGN KEY (tenant_id, publication_id, revision)
                REFERENCES publications(tenant_id, publication_id, revision),
            FOREIGN KEY (tenant_id, asset_id) REFERENCES assets(tenant_id, asset_id)
        );
        CREATE INDEX IF NOT EXISTS idx_review_cases_queue
            ON review_cases(tenant_id, applicability_status, candidate_status);
        CREATE TABLE IF NOT EXISTS audit_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            tenant_id TEXT NOT NULL,
            event_type TEXT NOT NULL,
            object_id TEXT NOT NULL,
            event_json TEXT NOT NULL,
            created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
        );
        """)
        columns = {row[1] for row in db.execute("PRAGMA table_info(review_cases)").fetchall()}
        for name, declaration in (
            ("review_decision", "TEXT"),
            ("reviewer", "TEXT"),
            ("review_notes", "TEXT"),
            ("reviewed_at", "TEXT"),
        ):
            if name not in columns:
                db.execute(f"ALTER TABLE review_cases ADD COLUMN {name} {declaration}")


def save_assets(tenant_id: str, assets: list[dict[str, Any]]) -> int:
    with connect() as db:
        for asset in assets:
            db.execute(
                "INSERT INTO assets(tenant_id, asset_id, payload_json) VALUES(?,?,?) "
                "ON CONFLICT(tenant_id, asset_id) DO UPDATE SET payload_json=excluded.payload_json",
                (tenant_id, asset["asset_id"], json.dumps(asset)),
            )
    return len(assets)


def assets_for(tenant_id: str) -> list[dict[str, Any]]:
    with connect() as db:
        rows = db.execute("SELECT payload_json FROM assets WHERE tenant_id=? ORDER BY asset_id", (tenant_id,)).fetchall()
    return [json.loads(row[0]) for row in rows]


def save_publication_and_cases(tenant_id: str, publication: dict[str, Any], cases: list[dict[str, Any]]) -> bool:
    key = (tenant_id, publication["publication_id"], publication["revision"])
    with connect() as db:
        exists = db.execute(
            "SELECT 1 FROM publications WHERE tenant_id=? AND publication_id=? AND revision=?", key
        ).fetchone()
        if exists:
            return True
        db.execute(
            "INSERT INTO publications(tenant_id,publication_id,revision,source_channel,issuing_authority,"
            "document_kind,source_url,subject,payload_json) VALUES(?,?,?,?,?,?,?,?,?)",
            (*key, publication["source_channel"], publication["issuing_authority"], publication["document_kind"],
             str(publication["source_url"]), publication["subject"], json.dumps(publication, default=str)),
        )
        for case in cases:
            db.execute(
                "INSERT INTO review_cases(tenant_id,case_id,publication_id,revision,asset_id,candidate_status,match_reasons_json) "
                "VALUES(?,?,?,?,?,?,?)",
                (tenant_id, case["case_id"], publication["publication_id"], publication["revision"],
                 case["asset_id"], case["candidate_status"], json.dumps(case["match_reasons"])),
            )
        db.execute("INSERT INTO audit_events(tenant_id,event_type,object_id,event_json) VALUES(?,?,?,?)",
                   (tenant_id, "PUBLICATION_INGESTED", publication["publication_id"], json.dumps({"revision": publication["revision"], "cases": len(cases)})))
    return False


def list_cases(tenant_id: str, limit: int = 100) -> list[dict[str, Any]]:
    with connect() as db:
        rows = db.execute(
            "SELECT c.*, p.document_kind, p.issuing_authority, p.source_url, p.subject, a.payload_json AS asset_json "
            "FROM review_cases c JOIN publications p USING(tenant_id,publication_id,revision) "
            "JOIN assets a USING(tenant_id,asset_id) WHERE c.tenant_id=? ORDER BY c.created_at DESC LIMIT ?",
            (tenant_id, limit),
        ).fetchall()
    result = []
    for row in rows:
        item = dict(row)
        item["match_reasons"] = json.loads(item.pop("match_reasons_json"))
        item["asset"] = json.loads(item.pop("asset_json"))
        result.append(item)
    return result


def record_review_decision(tenant_id: str, case_id: str, decision: str, reviewer: str, notes: str) -> bool:
    """Record an explicit human decision; never changes compliance status."""
    with connect() as db:
        row = db.execute(
            "SELECT case_id FROM review_cases WHERE tenant_id=? AND case_id=?",
            (tenant_id, case_id),
        ).fetchone()
        if not row:
            return False
        db.execute(
            "UPDATE review_cases SET review_decision=?,reviewer=?,review_notes=?,"
            "reviewed_at=strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE tenant_id=? AND case_id=?",
            (decision, reviewer, notes, tenant_id, case_id),
        )
        db.execute(
            "INSERT INTO audit_events(tenant_id,event_type,object_id,event_json) VALUES(?,?,?,?)",
            (tenant_id, "HUMAN_REVIEW_RECORDED", case_id,
             json.dumps({"decision": decision, "reviewer": reviewer, "notes": notes})),
        )
    return True


def list_audit_events(tenant_id: str, limit: int = 100) -> list[dict[str, Any]]:
    with connect() as db:
        rows = db.execute(
            "SELECT event_type,object_id,event_json,created_at FROM audit_events "
            "WHERE tenant_id=? ORDER BY created_at DESC,id DESC LIMIT ?",
            (tenant_id, limit),
        ).fetchall()
    result = []
    for row in rows:
        item = dict(row)
        item["details"] = json.loads(item.pop("event_json"))
        result.append(item)
    return result
