from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import json
root=Path('.').resolve()
target=root.parent/'Tailwise-Client-Demo.zip'
include=['README.md','START-HERE.md','START-HERE.bat','START-HERE.ps1','.env.example','.gitignore','.python-version','requirements.txt','render.yaml','app','examples','lovable','n8n']
exclude_parts={'.git','.venv','__pycache__','data'}
with ZipFile(target,'w',ZIP_DEFLATED) as z:
    for entry in include:
        p=root/entry
        if p.is_file(): z.write(p,p.relative_to(root.parent))
        elif p.is_dir():
            for f in p.rglob('*'):
                if f.is_file() and not any(part in exclude_parts for part in f.parts) and f.suffix not in {'.pyc','.png','.db','.sqlite3'}:
                    z.write(f,f.relative_to(root.parent))
with ZipFile(target) as z:
    names=z.namelist()
    assert not any(n.endswith('/.env') or n=='aerodirective-engine/.env' for n in names)
    assert any(n.endswith('n8n/tailwise-ad-sb-intake-template.json') for n in names)
    json.loads(z.read(next(n for n in names if n.endswith('n8n/tailwise-ad-sb-intake-template.json'))))
print(f'Bundle: {target} ({target.stat().st_size} bytes), {len(names)} files; secret .env excluded; n8n JSON valid.')
