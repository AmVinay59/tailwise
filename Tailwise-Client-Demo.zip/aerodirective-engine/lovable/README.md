# Lovable API integration starter

Use `LOVABLE_BUILD_PROMPT.md` to generate the Lovable UI and copy `src/lib/aerodirectiveApi.ts` into the Lovable project's API library. Copy `.env.example` into the Lovable project's local environment and set `VITE_API_BASE_URL`.

The client only calls synthetic demo endpoints, which do not need browser-held secrets. Do not add the FastAPI bearer token or webhook secret to Lovable's `VITE_*` environment variables. Production fleet/intake routes require a server-side proxy or a verified user access token.

For local preview, FastAPI CORS must include Lovable's exact preview origin. For a published app, `localhost` will point at each visitor's own computer; use an HTTPS staging/production API hostname and configure that Lovable origin in FastAPI CORS. Keep this local FastAPI prototype behind a firewall.
