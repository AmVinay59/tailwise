# Lovable build prompt — AeroDirective Maintenance Intelligence

Paste this prompt into Lovable to create a hosted React client for the FastAPI engine. For a local demo, set the API base to `http://localhost:8000`. A hosted Lovable deployment cannot reach a developer's `localhost`; deploy FastAPI to a protected HTTPS staging host first and set that URL as the API base.

## Prompt

Build a responsive aviation maintenance operations web app named **AeroDirective** for airlines, CAMOs, and MROs. Use the existing dark navy maintenance sidebar, precise aircraft engineering language, high information density, and a restrained blue/teal palette. Include these screens: Operations Overview, AD/SB Register, Fleet & Components, Engineering Review, Source Monitor, and Audit Trail. Show publication number, authority, document kind, revision, source URL, manufacturer/model/serial/part scope, match evidence, review state, applicability state, compliance state, and reviewer rationale as separate fields.

Use a typed API client with `VITE_API_BASE_URL` and call the FastAPI REST API. In **demo mode**, use only these public synthetic endpoints:

- `POST /v1/demo/run` to create the fixed fictional demo dataset.
- `GET /v1/demo/cases` for the review queue.
- `GET /v1/demo/audit` for demo activity.
- `POST /v1/demo/cases/{case_id}/review` to record a synthetic reviewer entry.

No API key or webhook secret may be stored in browser code. Do not display fictional FAA/EASA/OEM feed data as live source coverage. Clearly identify the DEMO-TENANT and all synthetic sample notices. Show source channels as disconnected until configured. A reviewer entry must never change compliance state; applicability remains UNASSESSED in the demo engine. Do not generate airworthiness determinations, compliance recommendations, or maintenance instructions. When an endpoint returns 503, show a clear configuration message without exposing secrets.

For production routes, call them only through an authenticated server-side proxy or verified user session; never put `AERODIRECTIVE_API_KEY` or `AERODIRECTIVE_WEBHOOK_SECRET` in `VITE_*` values. Use React, TypeScript, accessible keyboard-operable controls, loading/empty/error states, and mobile navigation. Keep visual labels, filters, and tables aligned with aviation engineering workflows rather than generic CRM concepts.

## Local API connection

For Lovable's local preview, allow `http://localhost:3000` in FastAPI `CORS_ORIGINS`. For a hosted preview, add the exact Lovable origin (scheme and hostname) to `CORS_ORIGINS`, restart FastAPI, and use a staging backend with HTTPS. Do not expose a local development API directly to the public internet.
