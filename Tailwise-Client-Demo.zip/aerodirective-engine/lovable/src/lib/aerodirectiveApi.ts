const API_BASE = (import.meta.env.VITE_API_BASE_URL || "http://localhost:8000").replace(/\/$/, "");

export type ReviewCase = {
  case_id: string;
  tenant_id: string;
  publication_id: string;
  revision: string;
  asset_id: string;
  candidate_status: string;
  match_reasons: string[];
  applicability_status: "UNASSESSED";
  compliance_status: "OPEN";
  human_review_required: boolean;
  review_decision?: string | null;
  reviewer?: string | null;
  review_notes?: string | null;
  document_kind: string;
  issuing_authority: string;
  source_url: string;
  subject: string;
  asset: {
    asset_id: string;
    product_type: string;
    manufacturer?: string | null;
    model: string;
    serial_number?: string | null;
    part_numbers: string[];
  };
};

export type AuditEvent = {
  event_type: string;
  object_id: string;
  created_at: string;
  details: Record<string, unknown>;
};

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const response = await fetch(`${API_BASE}${path}`, {
    ...init,
    headers: { "Content-Type": "application/json", ...(init?.headers || {}) },
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    const detail = typeof payload.detail === "string" ? payload.detail : `Request failed (${response.status})`;
    throw new Error(detail);
  }
  return payload as T;
}

export const aerodirectiveApi = {
  runDemo: () => request<{ demo: boolean; assets: number; publications: number; candidate_cases_created: number }>(
    "/v1/demo/run", { method: "POST" },
  ),
  getDemoCases: () => request<{ tenant_id: string; cases: ReviewCase[]; notice: string }>("/v1/demo/cases"),
  getDemoAudit: () => request<{ tenant_id: string; events: AuditEvent[] }>("/v1/demo/audit"),
  recordDemoReview: (caseId: string, input: {
    decision: "REVIEWED_POTENTIAL_MATCH" | "REVIEWED_NO_MATCH" | "NEEDS_MORE_INFORMATION";
    reviewer: string;
    notes: string;
  }) => request<{ case_id: string; decision: string; compliance_status: "OPEN"; notice: string }>(
    `/v1/demo/cases/${encodeURIComponent(caseId)}/review`,
    { method: "POST", body: JSON.stringify(input) },
  ),
  runDemoAiExtraction: () => request<{
    extracted_fields: Record<string, unknown>;
    ai_notice: string;
    applicability_determined: false;
  }>("/v1/demo/ai/extract", { method: "POST" }),
};
