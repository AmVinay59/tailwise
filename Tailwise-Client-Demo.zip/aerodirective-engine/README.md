# Tailwise Aircraft Records Intelligence — client demonstration

This is a FastAPI-backed client demonstration for Tailwise, a modular aviation technical-records service concept. The web desk contains six service areas: AD/SB and technical-record reconciliation, PDF/text extraction, cited aviation reference search, n8n workflow automation, operational reporting, and managed AI automation. It includes a fictional fleet, human-review queue, audit events, AI-assisted intake, an importable inactive n8n template, and exportable demo reports. It is not an airworthiness determination or a production aviation compliance system.

## Architecture in this starter

```text
FAA/EASA/OEM authorized notices
          │ (subscription / approved mailbox adapter)
          ▼
     n8n intake workflow ───► Python API ───► tenant-scoped records / review queue
          │                         │
          └── alerts via SMTP       └── optional AI field extraction (suggestions only)
                                       ▼
                              web app / reviewer sign-off
```

The Python service is the owner of normalized records and matching logic. n8n coordinates source delivery and alerts. The web app should call the Python API, not access n8n's database. Current storage is SQLite for local learning and synthetic demo records; migrate to PostgreSQL, migrations, tenant-specific identity, and hardened deployment before any real customer fleet data.

## Run locally on Windows PowerShell

1. Python 3.9 or later is supported. In this folder, run `py -m venv .venv` then `\.venv\Scripts\Activate.ps1`.
2. Run `pip install -r requirements.txt`.
3. Copy `.env.example` to `.env`; set different random secrets of at least 32 characters for `AERODIRECTIVE_API_KEY` and `AERODIRECTIVE_WEBHOOK_SECRET`. Add your OpenAI API key for AI extraction. Do not use ChatGPT login credentials as an API key. Never commit `.env` or paste its values into chat.
4. Run `uvicorn app.main:app --env-file .env --host 0.0.0.0 --port 8000 --reload`. The all-interface bind lets Docker-based n8n reach the host using `host.docker.internal`; keep the service behind your local firewall and do not expose port 8000 to the internet.
5. Open `http://127.0.0.1:8000/demo` for the aviation maintenance application, or `/docs` for API documentation. The app includes the six Tailwise services, along with the AD/SB register, fleet and component register, engineering review queue, source monitor, and audit trail.
6. Click **Run demo scenario**. The three fictional publications and three synthetic fleet assets are persisted locally. Record a sample reviewer disposition to demonstrate the audit trail; applicability stays `UNASSESSED` and compliance stays `OPEN`.
7. POST to `/v1/demo/run` to seed/reset by repeatable synthetic data. The demo endpoints only read/write `DEMO-TENANT`, with `DEMO-` identifiers and `example.invalid` links.

The **Tailwise services** navigation presents the client-facing service suite. Open **Records reconciliation** to export the synthetic evidence-gap CSV; **Document extraction & OCR** to submit authorized PDF or text; **Aviation document search** to ask the cited AI assistant or search the starter references; **Workflow automation** to download the inactive n8n template; **Operational reporting** for the demo metrics CSV; and **Managed AI automation** for the proposed customer onboarding and managed-service package. For PDF extraction, PDF bytes are sent to the configured OpenAI-compatible Responses endpoint and are not stored locally by this endpoint. AI results are unverified and do not create compliance decisions.

## Deploy a synthetic staging demo (Render)

`render.yaml` defines a **staging-only** FastAPI service with a persistent disk for synthetic demo records and an HTTP Basic password gate for a single pilot account. It is not multi-user customer authentication or production-grade tenant isolation. Do not upload customer fleet, maintenance, or source documents to this deployment.

1. Ensure `.env` stays untracked (`git check-ignore .env` should print `.env`). Create a **private** GitHub repository and push this project folder. Do not add `.env`, `.venv`, or local database files.
2. In Render, choose **New → Blueprint**, connect the private repository, review the Blueprint, and create the `aerodirective-staging` service. The blueprint uses a paid Starter web service and a 1 GB persistent disk; review the current price in Render before confirming. Render's Python deployment supports a build command and Uvicorn start command.
3. During Blueprint creation, provide `OPENAI_API_KEY` and a strong `STAGING_PASSWORD`; the staging username is `pilot`. Render generates separate values for the API and webhook secrets. Give the pilot login to the customer through a secure channel. Never put these secrets in Lovable/browser settings.
4. Save the variables and deploy/redeploy. Confirm `https://<your-render-service>.onrender.com/health` returns `status: ok`, then open `/demo`. The browser prompts for username `pilot` and the staging password you set. Click **Run demo scenario** and use fictional records only.
5. Share the HTTPS `/demo` URL and pilot login through separate secure channels. The bundled web app is served by the same FastAPI service, so it does not need a separate Lovable deployment for this staging demo. The Lovable client kit is for a later integration after real customer identity and authorization are implemented.
6. Keep n8n inactive until the staging API and source workflow are verified. The service currently uses SQLite and a single shared pilot login. Staging is for synthetic demonstration only, not customer daily operations.

Render's Blueprint documentation supports defining web services, health checks, generated/private environment variables, and disks in `render.yaml`. A persistent disk requires a paid service plan, and this SQLite staging setup should run as a single instance. Deployment is not complete until the GitHub repository is connected and the Render Blueprint is created in your account.

## API walkthrough

Protected endpoints need `Authorization: Bearer <AERODIRECTIVE_API_KEY>` and `X-Tenant-ID: <tenant id>`.

1. `PUT /v1/fleet` loads a customer-authorized fleet snapshot.
2. `POST /v1/intake` ingests one normalized publication revision, deduplicates on tenant + publication ID + revision, compares scope conservatively, and creates review cases.
3. `GET /v1/review-cases` returns the review queue.
4. `POST /v1/ai/extract` suggests structured fields from source text. An authorized reviewer must verify every extracted field against the official original before intake. AI is prohibited from deciding applicability or compliance.
5. `POST /v1/webhooks/ad-sb` accepts the authenticated source webhook: `X-Webhook-Secret`, `X-Tenant-ID`, and JSON fields `source_channel`, `source_message_id`, `source_url`, and `source_text`. It extracts fields, validates them, matches the tenant fleet, deduplicates, and returns candidate cases. It fails closed when AI is not configured or required fields are missing.

Use `examples/webhook-demo-payload.json` only as fictional test text. The webhook request requires `X-Tenant-ID: DEMO-TENANT` and `X-Webhook-Secret` copied locally from `.env`; a correct token alone is insufficient if the OpenAI API key is still blank.

`POST /v1/demo/run` creates fictional FAA/EASA/OEM-labelled examples for product demonstrations. Repeat runs are idempotent. `GET /v1/demo/cases` feeds the demo web page; `POST /v1/demo/cases/{case_id}/review` records a synthetic human-review entry in the audit log. `POST /v1/demo/document-extract?authorized_for_ai_processing=true` accepts a PDF upload of at most 15 MB. `POST /v1/demo/document-search` answers only from the fixed starter references and requires explicit AI-processing consent. Demo endpoints have no customer identity/tenant authorization and must not receive customer-controlled fleet or technical records. Don't connect live notices or real fleets to demo endpoints.

## n8n

Import `n8n/aerodirective-python-demo.json` into your local n8n instance. It is an inactive workflow with a manual trigger, Python demo seeding, and review-queue retrieval. The URLs use `http://host.docker.internal:8000` for n8n running in Docker on Windows. If n8n is not in Docker, change them to `http://127.0.0.1:8000`. Start Python first, then execute the manual trigger. The workflow makes no external email sends.

Import `n8n/aerodirective-authenticated-ad-sb-webhook.json` for the inactive source-intake draft. Create an n8n **Header Auth** credential with header name `X-Webhook-Secret` and the same private value as `AERODIRECTIVE_WEBHOOK_SECRET` in FastAPI's `.env`; attach it to both the incoming Webhook trigger and outgoing HTTP Request node. Configure the FastAPI OpenAI API key and tenant fleet, then submit a fictional test payload. The HTTP node uses `host.docker.internal` for Windows Docker. Keep the workflow inactive until source authorization and both authentication layers are verified. Do not put the shared secret in the exported workflow JSON or an expression.

The Tailwise dashboard also downloads `tailwise-n8n-intake-template.json`. It is inactive and contains a secured webhook → FastAPI → SMTP alert path. It routes sample alerts to `officialvinay0909@gmail.com`. After import, select the saved Header Auth credential on the webhook and HTTP Request nodes, set the tenant ID, select the saved SMTP credential, and set a valid sender address. No credential values are embedded in the export. The inactive workflow does not send mail until you choose credentials, set the sender, and activate it.

### Optional AI extraction

Import `n8n/aerodirective-ai-demo.json` for a separate inactive AI demo workflow. It calls a Python endpoint that sends only a fixed fictional sample to the model. Add your OpenAI API key to the private `.env` and restart Python before executing this workflow. For approved operational documents, `POST /v1/ai/extract` requires the engine API key and tenant header. The API uses structured output to return proposed fields plus uncertainty notes. AI does not decide applicability, compliance, or maintenance actions. Compare every suggested value against the official publication before intake. OpenAI processing transmits source text; only use material that your source terms and customer have approved for this processing.

The webhook workflow calls FastAPI, which performs extraction, schema validation, matching, and deduplication. It returns unverified fields and candidate cases only; it does not determine applicability or compliance.

## Product build order

1. **Local engine and demo web desk:** schemas, deduplication, candidate queue, synthetic review audit (this starter).
2. **n8n orchestration:** authenticated FAA/EASA/OEM email or API adapters, retries, dead-letter queue, source health, and email review alerts.
3. **Customer web app:** tenant login, fleet import/diff, review queue, evidence panel, reviewer/approver roles, and audit export. Start as a separate web client calling the Python API; do not expose API secrets in browser JavaScript.
4. **Production controls:** PostgreSQL migrations, tenant-level authorization tests, secret vault, TLS, backups, retention, rate limits, malware/attachment controls, audit immutability, and security review.
5. **Pilot:** configure one customer-authorized fleet and one source channel; reconcile false negatives and false positives with aviation engineering before widening coverage.

## Lovable web app

The working demo app is served by FastAPI at `/demo` and reads synthetic-only demo endpoints. `lovable/LOVABLE_BUILD_PROMPT.md` is the Lovable implementation brief. For local Lovable preview, use `VITE_API_BASE_URL=http://localhost:8000` and allow the exact frontend origin in `CORS_ORIGINS`. A hosted Lovable site cannot access your computer's `localhost`; deploy FastAPI to a protected HTTPS staging host first. Never put FastAPI or webhook secrets in `VITE_*` browser variables. Use an authenticated server-side proxy or verified user session for production APIs.

## Guardrails

- Candidate matches remain `UNASSESSED`; no code path sets a publication to applicable, not applicable, compliant, or accomplished.
- Human review is always required. The official publication and customer configuration/effectivity records remain the evidence of record.
- Keep restricted OEM documents out of third-party AI processing unless the customer has explicitly approved the processing and licensing permits it.
- FAA/EASA subscriptions are product-filtered, and OEM channels differ. This starter has no live regulator feed and does not claim complete coverage.
