# Start Tailwise demo

## Windows quick start

1. Install Python 3.9 or newer if it is not installed.
2. Double-click `START-HERE.bat`.
3. Paste your OpenAI API key into the hidden prompt and press Enter. The key is written only to this folder's private `.env`; it is never printed.
4. Wait for dependency installation. The launcher starts FastAPI and opens the demo page when it is ready.
5. In the app, click **Run demo scenario**. Try the Tailwise services: export a sample reconciliation, search cited references, download the inactive n8n starter, or upload an authorized PDF in **Document extraction & OCR**. All included fleet and maintenance records are fictional.
6. Keep the terminal window open while using the demo. Press Ctrl+C in that window to stop the server.

The launcher creates separate local API and webhook secrets automatically. `.env`, local SQLite data, screenshots, and the Python virtual environment are excluded from the project Git repository and downloadable ZIP.

## Important

This starts a local synthetic-data demo on your computer. It does not publish the service to the internet or make it ready for a customer's real fleet. For hosted staging, follow `README.md` → **Deploy a synthetic staging demo (Render)**. Do not enter real fleet or maintenance data into this demo: it has no customer login or tenant isolation.

The hosted staging version asks for one shared pilot username/password. It is an access gate for a fictional-data demo, not per-person accounts or an operational customer system.

OpenAI API usage is billed separately from a ChatGPT subscription.
