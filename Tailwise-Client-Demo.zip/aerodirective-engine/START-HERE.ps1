$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot

function Set-EnvValue([System.Collections.Generic.List[string]]$Lines, [string]$Name, [string]$Value) {
    $pattern = '^\s*' + [regex]::Escape($Name) + '\s*='
    $found = $false
    for ($i = 0; $i -lt $Lines.Count; $i++) {
        if ($Lines[$i] -match $pattern) {
            $Lines[$i] = "$Name=$Value"
            $found = $true
        }
    }
    if (-not $found) { $Lines.Add("$Name=$Value") }
}

function Get-EnvValue([System.Collections.Generic.List[string]]$Lines, [string]$Name) {
    $pattern = '^\s*' + [regex]::Escape($Name) + '\s*='
    foreach ($line in $Lines) {
        if ($line -match $pattern) { return ($line -split '=', 2)[1].Trim() }
    }
    return ''
}

function New-Secret {
    $bytes = New-Object byte[] 32
    $generator = [System.Security.Cryptography.RandomNumberGenerator]::Create()
    try { $generator.GetBytes($bytes) } finally { $generator.Dispose() }
    return [Convert]::ToBase64String($bytes)
}

function Read-OpenAIKey {
    $secureValue = Read-Host 'Paste your OpenAI API key (input is hidden)' -AsSecureString
    if ($secureValue.Length -eq 0) { throw 'No API key entered. Nothing was started.' }
    $pointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secureValue)
    try { return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($pointer) }
    finally {
        [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($pointer)
        $secureValue.Dispose()
    }
}

try {
    if (-not (Test-Path -LiteralPath '.env')) {
        Copy-Item -LiteralPath '.env.example' -Destination '.env'
    }

    $lines = [System.Collections.Generic.List[string]]::new()
    foreach ($line in (Get-Content -LiteralPath '.env')) { $lines.Add($line) }

    $savedKey = Get-EnvValue $lines 'OPENAI_API_KEY'
    if ([string]::IsNullOrWhiteSpace($savedKey)) {
        $apiKey = Read-OpenAIKey
        Set-EnvValue $lines 'OPENAI_API_KEY' $apiKey
        $apiKey = $null
    } else {
        $keepKey = Read-Host 'A key is already saved in .env. Keep it? [Y/n]'
        if ($keepKey -match '^(n|no)$') {
            $apiKey = Read-OpenAIKey
            Set-EnvValue $lines 'OPENAI_API_KEY' $apiKey
            $apiKey = $null
        }
    }

    foreach ($name in @('AERODIRECTIVE_API_KEY', 'AERODIRECTIVE_WEBHOOK_SECRET')) {
        $currentValue = Get-EnvValue $lines $name
        if ([string]::IsNullOrWhiteSpace($currentValue) -or $currentValue -match '^replace-with-') {
            Set-EnvValue $lines $name (New-Secret)
        }
    }
    Set-EnvValue $lines 'DATABASE_PATH' './data/aerodirective.sqlite3'
    Set-EnvValue $lines 'OPENAI_MODEL' 'gpt-5-mini'
    Set-Content -LiteralPath '.env' -Value $lines -Encoding ascii
    Write-Host 'Private local settings saved in .env (this file is excluded from Git).'

    if (-not (Test-Path -LiteralPath '.venv\Scripts\python.exe')) {
        if (-not (Get-Command py -ErrorAction SilentlyContinue)) {
            throw 'Python 3.9+ is required. Install Python from python.org, enable the Python Launcher, then run START-HERE.bat again.'
        }
        & py -3 -m venv .venv
        if ($LASTEXITCODE -ne 0) { throw 'Could not create the Python virtual environment.' }
    }

    $python = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
    & $python -m pip install -r requirements.txt
    if ($LASTEXITCODE -ne 0) { throw 'Dependency installation failed. Check your internet connection and try again.' }

    $portOwner = Get-NetTCPConnection -LocalPort 8000 -State Listen -ErrorAction SilentlyContinue
    if ($portOwner) { throw 'Port 8000 is already in use. Stop the existing FastAPI window (Ctrl+C), then run START-HERE.bat again.' }

    Write-Host ''
    Write-Host 'Starting Tailwise client demo. Keep this window open; press Ctrl+C to stop.'
    Write-Host 'Demo URL: http://localhost:8000/demo'
    Write-Host 'Health:   http://localhost:8000/health'

    $browserJob = Start-Job -ArgumentList 'http://localhost:8000' -ScriptBlock {
        param($baseUrl)
        for ($attempt = 0; $attempt -lt 40; $attempt++) {
            try {
                $response = Invoke-WebRequest -Uri "$baseUrl/health" -TimeoutSec 2
                if ($response.StatusCode -eq 200) {
                    Start-Process "$baseUrl/demo"
                    return
                }
            } catch { }
            Start-Sleep -Milliseconds 500
        }
    }
    try {
        & $python -m uvicorn app.main:app --env-file .env --host 0.0.0.0 --port 8000
    } finally {
        if ($browserJob) { Remove-Job -Job $browserJob -Force -ErrorAction SilentlyContinue }
    }
} catch {
    Write-Host "`nCould not start: $($_.Exception.Message)" -ForegroundColor Red
    Read-Host 'Press Enter to close'
    exit 1
}
